$(document).ready(function() {
    var botao = $('input[name="0"]').val();

});

function display(valor){
    $('#display').val(valor)

}